package com.demo.test;

import java.util.Scanner;

public class TestCrudOperation {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice=0;
		
		ProductService productService = new ProductServiceImpl();
		
		do {
			System.out.println("1.add\n2.Search\n3.dispaly\n4.delete\n5.display by id\n6.exit");
			System.out.println("choice");
			choice=sc.nextInt();
			
		}
		switch(choice) {
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			exit();
			
		}
		
	}
}
