package com.demo.service;

public class ProductServiceImpl implements ProductService {
	private Product
}
