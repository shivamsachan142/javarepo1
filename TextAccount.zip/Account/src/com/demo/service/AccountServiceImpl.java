package com.demo.service;

import java.util.Scanner;

import com.demo.bean.Account;
import com.demo.dao.AccountDao;
import com.demo.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	private AccountDao accountDao;
	
	public AccountServiceImpl() {
		accountDao = new AccountDaoImpl();
	}
	
//	private int id;
//	private String name;
//	private String type;
//	private double balance;
//	private String date;
//	@Override
//	public void addAccount() {
//		// TODO Auto-generated method stub
//		Scanner sc= new Scanner(System.in);
//		System.out.println("enter text : ");
//		String text=sc.nextLine();
//		
//		Account a= new Account(text);
//		accountDao.addAccount(a);
//	}

	@Override
	public void addTextNote(String text) {
		// TODO Auto-generated method stub
		accountDao.addTextNote(text);
	}

	@Override
	public void addTextNoteUrl(String texturl) {
		// TODO Auto-generated method stub
		accountDao.addTextNoteUrl(texturl);
	}

	@Override
	public void displayAllText() {
		// TODO Auto-generated method stub
		accountDao.displayAllText();
	}

	@Override
	public void displayAllTextUrl() {
		// TODO Auto-generated method stub
		accountDao.displayAllTextUrl();
	}

	

	

	
	
}
