package com.demo.service;

import com.demo.bean.Account;

public interface AccountService {

//	void addAccount();

	void addTextNote(String text);

	void addTextNoteUrl(String texturl);

	void displayAllText();

	void displayAllTextUrl();

}
