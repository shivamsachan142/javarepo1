package com.demo.dao;

import com.demo.bean.Account;

public interface AccountDao {

//	void addAccount(Account a);

	void addTextNote(String text);

	void addTextNoteUrl(String texturl);

	void displayAllText();

	void displayAllTextUrl();

}
