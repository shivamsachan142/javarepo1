package com.demo.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.demo.bean.Account;
//import com.demo.bean.Product;


public class AccountDaoImpl implements AccountDao{
	
	static List<Account> plisttext;
	static List<Account> plisttexturl;
	static {
		plisttext=new ArrayList<>();
//		plisttext.add(new Account("name of book"));
//		plisttext.add(new Account("name of other book"));
	}
	static {
		plisttexturl=new ArrayList<>();
//		plisttexturl.add(new Account("name of book"));
//		plisttexturl.add(new Account("name of other book"));
	}
	
//	@Override
//	public void addAccount(Account a) {
//		// TODO Auto-generated method stub
//		plisttext.add(a);
//	}

	@Override
	public void addTextNote(String text) {
		// TODO Auto-generated method stub
		plisttext.add(new Account(text));
	}

	@Override
	public void addTextNoteUrl(String texturl) {
		// TODO Auto-generated method stub
		plisttexturl.add(new Account(texturl));
	}

	@Override
	public void displayAllText() {
		// TODO Auto-generated method stub
		
		for(Account a : plisttext) {
			System.out.println(a);
		}
	}

	@Override
	public void displayAllTextUrl() {
		// TODO Auto-generated method stub
		for(Account a : plisttext) {
			System.out.println(a);
		}
	}
	
	
}
