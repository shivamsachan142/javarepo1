package com.demo.bean;

public class TextAndImageNote extends Text {
	
	private String urrl;

	public TextAndImageNote() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TextAndImageNote(String texxt) {
		super(texxt);
		// TODO Auto-generated constructor stub
	}

	public String getUrrl() {
		return urrl;
	}

	public void setUrrl(String urrl) {
		this.urrl = urrl;
	}
	
	
	
	
	
	
}
