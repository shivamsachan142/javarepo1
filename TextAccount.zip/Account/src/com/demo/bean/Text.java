package com.demo.bean;

abstract public class Text {
	private String texxt;

	public Text() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Text(String texxt) {
		super();
		this.texxt = texxt;
	}

	public String getTexxt() {
		return texxt;
	}

	public void setTexxt(String texxt) {
		this.texxt = texxt;
	}

	@Override
	public String toString() {
		return "Text [texxt=" + texxt + "]";
	}
	
	
}
