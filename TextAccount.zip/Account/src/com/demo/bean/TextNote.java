package com.demo.bean;

public class TextNote extends Text{

	public TextNote() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TextNote(String texxt) {
		super(texxt);
		// TODO Auto-generated constructor stub
	}
	
}
