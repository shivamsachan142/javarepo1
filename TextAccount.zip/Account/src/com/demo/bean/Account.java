package com.demo.bean;

public class Account {
	
	private String text;
	
	public boolean equals(Object ob) {
		if(text==((Account)ob).text) {
			return true;
		}
		return false;
	}
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(String text) {
		super();
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "Account [text=" + text + "]";
	}

	

	
	
	
	
}
