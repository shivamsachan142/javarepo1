package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.bean.Account;
//import com.demo.bean.Product;
import com.demo.service.AccountService;
import com.demo.service.AccountServiceImpl;

public class AccountManager {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice=0;
		
		AccountService accountService = new AccountServiceImpl();
		
		
		accountService.addTextNote("Java is a set of cs and specifications developed by james gosling microsystem");
		accountService.addTextNote("few books to read, how to win friends and influence people");
		accountService.addTextNoteUrl("the shopping list on my fridge, //ad/ad/ad/.jpg");
		accountService.addTextNoteUrl("size label of jack shirt, //daa//ada/da//da.jpeg");
		
		while(choice!=5) {
			System.out.println("1.add textnote\n2.add text and image note\n3.display all text note\n4.display all text&url note\n5.exit");
			choice =sc.nextInt();
			if(choice==1) {
				System.out.println("enter text : ");
				String text=sc.next();
				accountService.addTextNote(text);
			}
			else if(choice==2) {
				System.out.println("enter text : ");
				String text=sc.nextLine();
				System.out.println("enter text : ");
				String url=sc.nextLine();
				String texturl=text+" , "+url;
				accountService.addTextNoteUrl(texturl);
			}
			else if(choice==3) {
				//accountService.withdrawAmount();
				accountService.displayAllText();
			}
			else if(choice==4) {
				accountService.displayAllTextUrl();
			}
			else {
				System.out.println("enter values in given range");
			}
		}
		sc.close();
	}
}
