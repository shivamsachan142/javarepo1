package com.demo.test;
import java.util.Date;
import java.util.Scanner;

import com.demo.service.PersonService;

public class TestPersonArray {
	static {
		
		System.out.println("In static block");
	}
      
	public static void main(String[] args) {
		//Scanner sc=new Scanner(System.in);
		//PersonService ps=new PersonService();
		final int i=0;
		PersonService.acceptData();
		//i=12;
		PersonService.dispalyData();
		
		
		
	}

}
