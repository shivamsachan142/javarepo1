package com.demo.dao;

import java.util.ArrayList;
import java.util.List;

import com.demo.bean.Text;
import com.demo.bean.TextAndImageNote;



public class TextDaoImpl implements TextDao {
	
	static List<Text> plist = new ArrayList<>();
	
	
	@Override
	public void addTextNote(String string) {
		// TODO Auto-generated method stub
		plist.add(new Text(string));
	}


	@Override
	public void addTextNoteUrl(String string, String string2) {
		// TODO Auto-generated method stub
		plist.add(new TextAndImageNote(string,string2));
	}


	@Override
	public ArrayList<Text> displayAllText() {
		// TODO Auto-generated method stub
		ArrayList<Text> arr = new ArrayList<Text>();
		for(Text t : plist) {
			if(t instanceof Text && !(t instanceof TextAndImageNote)) {
				arr.add(t);
			}
		}
		return arr;
	}


	@Override
	public ArrayList<Text> displayAllTextUrl() {
		// TODO Auto-generated method stub
		ArrayList<Text> arr = new ArrayList<Text>();
		for(Text t : plist) {
			if(t instanceof TextAndImageNote) {
				arr.add(t);
			}
		}
		return arr;
	}

}
