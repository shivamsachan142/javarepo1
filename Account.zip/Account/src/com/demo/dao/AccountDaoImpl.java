package com.demo.dao;

import java.util.ArrayList;
import java.util.List;

import com.demo.bean.Account;
//import com.demo.bean.Product;


public class AccountDaoImpl implements AccountDao{
	
	static List<Account> plist;
	
	static {
		plist=new ArrayList<>();
		plist.add(new Account(12,"shivam","saving",2000.0,"12/12/21",6));
		plist.add(new Account(13,"Nitish","current",3000.0,"12/12/12",7));
	}
	
	@Override
	public void addAccount(Account a) {
		// TODO Auto-generated method stub
		plist.add(a);
	}

	@Override
	public boolean closeAccount(int id) {
		// TODO Auto-generated method stub
		Account a= new Account(id,null,null,0.0,null,0);
		int pos = plist.indexOf(a);
		if(pos!=-1) {
			plist.remove(pos);
			return true;
		}
		return false;
	}

	@Override
	public void displayAll() {
		// TODO Auto-generated method stub
		for(Account a : plist) {
			System.out.println(a);
		}
		
	}

	@Override
	public boolean check(int idd) {
		// TODO Auto-generated method stub
		Account a =new Account(idd,null,null,0.0,null,0);
		int pos = plist.indexOf(a);
		if(pos!=-1) return true;
		return false;
	}

	@Override
	public boolean deposit(int iddd, double amt) {
		// TODO Auto-generated method stub
		Account a =new Account(iddd,null,null,0.0,null,0);
		int pos=plist.indexOf(a);
		if(pos!=-1) {
			//plist.set(pos, element)
			//double val=plist.get(pos).getBalance();
			plist.set(pos, new Account(plist.get(pos).getId(),plist.get(pos).getName(),plist.get(pos).getType(),plist.get(pos).getBalance()+amt,plist.get(pos).getDate(),plist.get(pos).getTransactions()));
			return true;
		}
		else {
			return false;
		}
	}

//	@Override
//	public boolean withdraw(int idddd, double amtt, String typ) {
//		// TODO Auto-generated method stub
//		Account a =new Account(idddd,null,null,0.0,null,0);
//		int pos=plist.indexOf(a);
//		if(pos!=-1) {
//			//plist.set(pos, element)
//			double val=plist.get(pos).getBalance();
//			plist.set(pos, new Account(idddd,null,null,val-amtt,null,0));
//			return true;
//		}
//		else {
//			return false;
//		}
//	}

	@Override
	public boolean withdrawSavings(int idddd, double amtt, String typ, double minBalance) {
		// TODO Auto-generated method stub
		Account a =new Account(idddd,null,null,0.0,null,0);
		int pos=plist.indexOf(a);
		if(pos!=-1) {
			double val=plist.get(pos).getBalance();
			if(val-amtt>=minBalance && plist.get(pos).getType().equals(typ)) {
				plist.set(pos, new Account(plist.get(pos).getId(),plist.get(pos).getName(),plist.get(pos).getType(),plist.get(pos).getBalance()-amtt,plist.get(pos).getDate(),plist.get(pos).getTransactions()+1));
				
				return true;
			}
			else return false;
		}
		else {
			return false;
		}
		
	}

	@Override
	public boolean withdrawCurrent(int idddd, double amtt, String typ, int maxTransactions) {
		// TODO Auto-generated method stub
		Account a =new Account(idddd,null,null,0.0,null,0);
		int pos=plist.indexOf(a);
		if(pos!=-1) {

			if(plist.get(pos).getTransactions()<maxTransactions && plist.get(pos).getBalance()-amtt>=0 && plist.get(pos).getType().equals(typ)) {
				plist.set(pos, new Account(plist.get(pos).getId(),plist.get(pos).getName(),plist.get(pos).getType(),plist.get(pos).getBalance()-amtt,plist.get(pos).getDate(),plist.get(pos).getTransactions()+1));
				
				return true;
			}
			else return false;
		}
		else {
			return false;
		}
	}

	
	
}
