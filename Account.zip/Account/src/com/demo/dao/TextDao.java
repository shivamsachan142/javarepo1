package com.demo.dao;

import java.util.ArrayList;

import com.demo.bean.Text;

public interface TextDao {

	void addTextNote(String string);

	void addTextNoteUrl(String string, String string2);

	ArrayList<Text> displayAllText();

	ArrayList<Text> displayAllTextUrl();

}
