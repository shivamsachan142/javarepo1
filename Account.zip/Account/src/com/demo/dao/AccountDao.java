package com.demo.dao;

import com.demo.bean.Account;

public interface AccountDao {

	void addAccount(Account a);

	boolean closeAccount(int id);

	void displayAll();

	boolean check(int idd);

	boolean deposit(int iddd, double amt);

	boolean withdrawSavings(int idddd, double amtt, String typ, double minBalance);

	boolean withdrawCurrent(int idddd, double amtt, String typ, int maxTransactions);


	//Account closeAccount(Account a);

}
