package com.demo.service;

import java.util.Scanner;

import com.demo.bean.Account;
import com.demo.dao.AccountDao;
import com.demo.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	private AccountDao accountDao;
	static double minBalance = 1000.0;
	static int maxTransactions=10;
	public AccountServiceImpl() {
		accountDao = new AccountDaoImpl();
	}
	
//	private int id;
//	private String name;
//	private String type;
//	private double balance;
//	private String date;
	@Override
	public void addAccount() {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter id : ");
		int id = sc.nextInt();
		System.out.println("enter name : ");
		String nm=sc.next();
		System.out.println("enter type : ");
		String ty=sc.next();
		System.out.println("enter balance : ");
		double bal=sc.nextDouble();
		System.out.println("enter date :");
		String dt=sc.next();
//		System.out.println("number of transactions :");
//		int trans=sc.nextInt();
		Account a= new Account(id,nm,ty,bal,dt,0);
		accountDao.addAccount(a);
	}

	@Override
	public boolean closeAccount(int id) {
		// TODO Auto-generated method stub
		
		return accountDao.closeAccount(id);
	}

	@Override
	public void displayAll() {
		accountDao.displayAll();
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean check(int idd) {
		// TODO Auto-generated method stub
		//Account a = new Account(idd,null,null,0.0,null);
		
		return accountDao.check(idd);
	}

	@Override
	public boolean deposit(int iddd, double amt) {
		// TODO Auto-generated method stub
		return accountDao.deposit(iddd,amt);
	}

	@Override
	public boolean withdraw(int idddd, double amtt, String typ) {
		// TODO Auto-generated method stub
		if(typ=="saving") {
			return accountDao.withdrawSavings(idddd,amtt,typ,minBalance);
		}
		else return accountDao.withdrawCurrent(idddd,amtt,typ, maxTransactions);
		
		
	}

	

	
	
}
