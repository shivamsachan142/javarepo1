package com.demo.service;

import com.demo.bean.Account;

public interface AccountService {

	void addAccount();

	boolean closeAccount(int id);

	void displayAll();

	boolean check(int idd);

	boolean deposit(int iddd, double amt);

	boolean withdraw(int idddd, double amtt, String typ);



}
