package com.demo.service;

import java.util.ArrayList;

import com.demo.bean.Text;

public interface TextService {

	void addTextNote(String string);

	void addTextNoteUrl(String string, String string2);

	ArrayList<Text> displayAllText();

	ArrayList<Text> displayAllTextUrl();
	
	

}
