package com.demo.service;

import java.util.ArrayList;

import com.demo.bean.Text;
import com.demo.dao.TextDao;
import com.demo.dao.TextDaoImpl;

public class TextServiceImpl implements TextService{
	
	private TextDao textDao;
	
	public TextServiceImpl() {
		textDao = new TextDaoImpl();
	}
	@Override
	public void addTextNote(String string) {
		// TODO Auto-generated method stub
		textDao.addTextNote(string);
	}
	
	@Override
	public void addTextNoteUrl(String string, String string2) {
		// TODO Auto-generated method stub
		textDao.addTextNoteUrl(string,string2);
	}
	@Override
	public ArrayList<Text> displayAllText() {
		// TODO Auto-generated method stub
		return textDao.displayAllText();
	}
	@Override
	public ArrayList<Text> displayAllTextUrl() {
		// TODO Auto-generated method stub
		return textDao.displayAllTextUrl();
	}

}
