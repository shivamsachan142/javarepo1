package com.demo.test;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.demo.bean.Text;

import com.demo.service.TextService;
import com.demo.service.TextServiceImpl;


public class  Launcher{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in).useDelimiter("\n");;
		int choice=0;
		
		TextService textService = new TextServiceImpl();
		
		
		textService.addTextNote("Java is a set of cs and specifications developed by james gosling microsystem");
		textService.addTextNote("few books to read, how to win friends and influence people");
		textService.addTextNoteUrl("the shopping list on my fridge", "//ad/ad/ad/.jpg");
		textService.addTextNoteUrl("size label of jack shirt", "//daa//ada/da//da.jpeg");
		
		while(choice!=5) {
			try {
			System.out.println("1.add textnote\n2.add text and image note\n3.display all text note\n4.display all text&url note\n5.exit");
			choice =sc.nextInt();
			if(choice==1) {
				System.out.println("enter text : ");
				//sc.next();
				String text=sc.next();
				
				textService.addTextNote(text);
			}
			else if(choice==2) {
				System.out.println("enter text : ");
				//sc.next();
				String text=sc.next();
				System.out.println("enter url : ");
				String url=sc.next();
				
//				String texturl=text+" , "+url;
				textService.addTextNoteUrl(text,url);
			}
			else if(choice==3) {
				//accountService.withdrawAmount();
				ArrayList<Text> arr = textService.displayAllText();
				for(Text t : arr) {
					System.out.println(t);
				}
				//List<new Text()> arr =  textService.displayAllText();
			}
			else if(choice==4) {
				ArrayList<Text> arr = textService.displayAllTextUrl();
				for(Text t : arr) {
					System.out.println(t);
				}
			}
			else {
				System.out.println("enter values in given range");
			}
			}catch(InputMismatchException e) {
				System.out.println(e.getMessage());
				break;
			}
		}
		sc.close();
	}
}