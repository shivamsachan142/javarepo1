package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.bean.Account;
//import com.demo.bean.Product;
import com.demo.service.AccountService;
import com.demo.service.AccountServiceImpl;

public class AccountManager {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice=0;
		
		AccountService accountService = new AccountServiceImpl();
//		do {
//			System.out.println("1.add account\n2.close account\n3.withdraw\n4.deposit\n5.check\n6.display all\n7.exit");
//			choice =sc.nextInt();
//		switch(choice){
//		case 1:
//			accountService.addAccount();
//			break;
//		case 2:
//			System.out.println("enter id to delete account : ");
//			int id=sc.nextInt();
//			boolean check = accountService.closeAccount(id);
//			if(check) {
//				System.out.println("account deleted");
//			}
//			else {
//				System.out.println("account not found");
//			}
//			break;
//		case 3:
//			//accountService.withdrawAmount();
//			System.out.println("enter id to withdraw :");
//			int idddd= sc.nextInt();
//			System.out.println("enter amount to withdraw : ");
//			double amtt = sc.nextDouble();
//			System.out.println("account type : saving/current?");
//			String typ=sc.next();
//			boolean flag2=accountService.withdraw(idddd,amtt,typ);
//			if(flag2) {
//				System.out.println("collect your cash");
//			}
//			else {
//				System.out.println("withdrawl can't be processed");
//			}
//			break;
//		case 4:
//			System.out.println("enter id to deposit :");
//			int iddd= sc.nextInt();
//			System.out.println("enter amount to deposit : ");
//			double amt = sc.nextDouble();
//			
//			boolean flag1 = accountService.deposit(iddd,amt);
//			if(flag1) {
//				System.out.println("amount deposited");
//			}
//			else {
//				System.out.println("amount not deposited due to incorrect id");
//			}
//			//accountService.depositAccount();
//			break;
//		case 5:
//			//accountService.checkBalance();
//			System.out.println("enter id to check : ");
//			int idd = sc.nextInt();
//			boolean flag = accountService.check(idd);
//			if(flag) {
//				System.out.println("account exists");
//			}
//			else {
//				System.out.println("account doesn't exist");
//			}
//			break;
//		case 6:
//			accountService.displayAll();
//			break;
//		case 7:
//			sc.close();
//			System.exit(0);
//		}
//		}while(choice!=5);
//	}
	
	while(choice!=7) {
		System.out.println("1.add account\n2.close account\n3.withdraw\n4.deposit\n5.check\n6.display all\n7.exit");
		choice =sc.nextInt();
		if(choice==1) {
			accountService.addAccount();
		}
		else if(choice==2) {
			System.out.println("enter id to delete account : ");
			int id=sc.nextInt();
			boolean check = accountService.closeAccount(id);
			if(check) {
				System.out.println("account deleted");
			}
			else {
				System.out.println("account not found");
			}
		}
		else if(choice==3) {
			//accountService.withdrawAmount();
			System.out.println("enter id to withdraw :");
			int idddd= sc.nextInt();
			System.out.println("enter amount to withdraw : ");
			double amtt = sc.nextDouble();
			System.out.println("account type : saving/current?");
			String typ=sc.next();
			boolean flag2=accountService.withdraw(idddd,amtt,typ);
			if(flag2) {
				System.out.println("collect your cash");
			}
			else {
				System.out.println("withdrawl can't be processed");
			}
		}
		else if(choice==4) {
			System.out.println("enter id to deposit :");
			int iddd= sc.nextInt();
			System.out.println("enter amount to deposit : ");
			double amt = sc.nextDouble();
			
			boolean flag1 = accountService.deposit(iddd,amt);
			if(flag1) {
				System.out.println("amount deposited");
			}
			else {
				System.out.println("amount not deposited due to incorrect id");
			}
			//accountService.depositAccount();
		}
		else if(choice==5) {
			//accountService.checkBalance();
			System.out.println("enter id to check : ");
			int idd = sc.nextInt();
			boolean flag = accountService.check(idd);
			if(flag) {
				System.out.println("account exists");
			}
			else {
				System.out.println("account doesn't exist");
			}
		}
		else if(choice==6) {
			accountService.displayAll();
		}
		else {
			System.out.println("enter values in given range");
		}
	}
	sc.close();
	}
}
