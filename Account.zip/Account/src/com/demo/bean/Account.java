package com.demo.bean;

public class Account {
	
	private int id;
	private String name;
	private String type;
	private double balance;
	private String date;
	private int transactions;
	
	public boolean equals(Object ob) {
		if(id==((Account)ob).id) {
			return true;
		}
		return false;
	}
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(int id, String name, String type, double balance, String date, int transactions) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.balance = balance;
		this.date = date;
		this.transactions = transactions;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getTransactions() {
		return transactions;
	}

	public void setTransactions(int transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", name=" + name + ", type=" + type + ", balance=" + balance + ", date=" + date
				+ ", transactions=" + transactions + "]";
	}

	
	
	
	
}
