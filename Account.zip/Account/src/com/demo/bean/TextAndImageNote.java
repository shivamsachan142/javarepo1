package com.demo.bean;

public class TextAndImageNote extends Text{
	
	private String url;

	public TextAndImageNote() {
		super();
		// TODO Auto-generated constructor stub
	}

//	public TextAndImageNote(String text) {
//		super(text);
//		// TODO Auto-generated constructor stub
//	}

	public TextAndImageNote(String text,String url) {
		super(text);
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {
		//return "TextAndImageNote [url=" + url + ", getText()=" + getText() +  "]";
		return "TextAndImageNote [text=" + getText() + ", [url=" + url +  "]";
	}

	

	

	
	
	
	
}