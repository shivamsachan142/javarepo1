package com.demo.bean;

public class Text {
	private String text;

	public Text() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Text(String text) {
		super();
		this.text = text;
	}



	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "Text [text=" + text + "]";
	}
	
}
